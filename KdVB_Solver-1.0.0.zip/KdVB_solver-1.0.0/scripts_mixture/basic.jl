using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"
include("dispersion_mixture.jl")


function AttenuationPlot(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)
    Reθ⁺ = Dispersion(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[1]
    Reθ⁻ = Dispersion(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[2]

    Imθ⁻ = Dispersion(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[4]
    vp = zeros(length(k))
    for i in [1:length(k);]
        vp[i] = -Imθ⁻[i] / k[i]
    end

    plt = default(
        xlabel = L"Wave number $[-]$",
        title = "Mixture model",
        tickfontsize = 12,
        guidefontsize = 14,
        legendfontsize = 11,
        titlefontsize = 14,
        fontfamily = plot_font,
        size = (600,350),
        rightmargin = 1.5Plots.cm,
    )

    plt = plot(k, vp,
        ylabel = L"$v_\mathrm{p} \,[-]$",
        ylim = (0, 0.5),
        color = "black",
        legend = false,
        linestyle = :solid
        )

    plt = plot!(twinx(), k, Reθ⁺, 
        linewidth = 1.5,
        alpha = 0.5,
        label=L"$\mathrm{Re} \,\,[\theta^{+}]$", 
        color="red", 
        ylabel = L"Attenuation Factor $[-]$",
        legend = (0.8,0.8),
        linestyle = :solid,
        ylim = (-8,0),
    )
    plt = plot!(twinx(), k, Reθ⁻, 
        linewidth = 1.5,
        alpha = 0.5,
        label=L"$\mathrm{Re} \,\,[\theta^{-}]$", 
        linestyle=:dot, 
        color="red",
        ylabel = L"Attenuation Factor $[-]$",
        legend = (0.8,0.65),
        ylim = (-8,0),
    )

    savefig("./scripts_mixture/fig/basic.pdf")
end

AttenuationPlot([0.01:0.01:100;], 0.05, 0.5, 10^2, 0.04, 2, 0.01, 0.3)