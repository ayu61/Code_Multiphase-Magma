using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"
include("dispersion_mixture.jl")

function PhaseVelo_R0(k, α0, μL_ast, φP, rp, Δ, σ_ast)
    Imθ_1 = Dispersion(k, α0, 0.1, μL_ast, φP, rp, Δ, σ_ast)[4]
    Imθ_2 = Dispersion(k, α0, 0.2, μL_ast, φP, rp, Δ, σ_ast)[4]
    Imθ_3 = Dispersion(k, α0, 0.5, μL_ast, φP, rp, Δ, σ_ast)[4]
    Imθ_4 = Dispersion(k, α0, 1.0, μL_ast, φP, rp, Δ, σ_ast)[4]

    vp1 = zeros(length(k))
    vp2 = zeros(length(k))
    vp3 = zeros(length(k))
    vp4 = zeros(length(k))
    for i in [1:length(k);]
        vp1[i] = -Imθ_1[i] / k[i]
        vp2[i] = -Imθ_2[i] / k[i]
        vp3[i] = -Imθ_3[i] / k[i]
        vp4[i] = -Imθ_4[i] / k[i]
    end

    Reθ⁺_1 = Dispersion(k, α0, 0.1, μL_ast, φP, rp, Δ, σ_ast)[1]
    Reθ⁻_1 = Dispersion(k, α0, 0.1, μL_ast, φP, rp, Δ, σ_ast)[2]

    Reθ⁺_2 = Dispersion(k, α0, 0.2, μL_ast, φP, rp, Δ, σ_ast)[1]
    Reθ⁻_2 = Dispersion(k, α0, 0.2, μL_ast, φP, rp, Δ, σ_ast)[2]

    Reθ⁺_3 = Dispersion(k, α0, 0.5, μL_ast, φP, rp, Δ, σ_ast)[1]
    Reθ⁻_3 = Dispersion(k, α0, 0.5, μL_ast, φP, rp, Δ, σ_ast)[2]

    Reθ⁺_4 = Dispersion(k, α0, 1.0, μL_ast, φP, rp, Δ, σ_ast)[1]
    Reθ⁻_4 = Dispersion(k, α0, 1.0, μL_ast, φP, rp, Δ, σ_ast)[2]

    plt = default(
        xlabel = L"Wave number $[-]$",
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :bottomleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
        rightmargin = 1.5Plots.cm,
    )

    plt = plot(k, vp1, 
        color="black", 
        label=L"$R^\ast_0 = 0.1\,\mathrm{mm}$",
        linestyle = :solid,
        ylabel = L"$v_\mathrm{p} \,[-]$",
        ylim = (0.2, 0.28),
    )
    plt = plot!(k, vp2, 
        color="black", 
        label=L"$R^\ast_0 = 0.2\,\mathrm{mm}$",
        linestyle = :dash
    )
    plt = plot!(k, vp3, 
        color="black", 
        label=L"$R^\ast_0 = 0.5\,\mathrm{mm}$",
        linestyle = :dot
    )
    plt = plot!(k, vp4, 
        color="black", 
        label=L"$R^\ast_0 = 1.0\,\mathrm{mm}$",
        linestyle = :dashdot
    )

    plt = plot!(twinx(), k, [Reθ⁺_1, Reθ⁻_1],
        color = "red",
        linestyle = :solid,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-2, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_2, Reθ⁻_2],
        color = "red",
        linestyle = :dash,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-2, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_3, Reθ⁻_3],
        color = "red",
        linestyle = :dot,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-2, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_4, Reθ⁻_4],
        color = "red",
        linestyle = :dashdot,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-2, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )

    savefig("./scripts_mixture/fig/PhaseVelo_R0.pdf")
end




PhaseVelo_R0([0.01:0.01:10;], 0.05, 10^2, 0.04, 2, 0.01, 0.3)