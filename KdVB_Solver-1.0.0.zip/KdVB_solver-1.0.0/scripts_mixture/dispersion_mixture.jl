using LinearAlgebra

## 引数一覧
# α0        ## 初期ボイド率 [-]
# φP        ## 実効媒質中における結晶の体積分率 [-] (固定値)
# R0mm_ast  ## 初期気泡半径 [mm]
# μL_ast    ## メルト粘度 [Pas]
# rp        ## アスペクト比 [-]
# Δ         ## 代表長さ(波の代表波長)に対する気泡半径の比
# σ_ast     ## 表面張力 [N/m] (含水率により0.05~0.3の値を取りうる)

function Dispersion(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)

    ## マグマの代表的なパラメータ
    ρA_ast = 2600       ## 実効媒質の密度 [kg/m³]
    Kb = 20*10^9        ## 体積弾性率 [Pa]
    Kr = 10^4*10^6      ## 剛性率 [Pa]

    ## 仮定 (気泡は球形・流れは定常・地下4km程度のマグマ溜まり条件)
    pA0_ast = 150*10^6      ## 実効媒質の圧力 [Pa]
    pG0_ast = pA0_ast + 2σ_ast      ## 気相の圧力 [Pa]
    R0_ast = R0mm_ast * 10^(-3)     ## 気泡半径 [m]
    κ = 1       ## ポリトロープ指数 [-]
    
    ## 実効粘度モデルのパラメータ
    φm = 0.55exp(-(log10(rp))^2/2)      ## Maximum packing fanction [-]
    
    ## 代表値
    U_ast = sqrt( (Kb + 4/3 * Kr) / ρA_ast )        ## 代表速度 (マグマ中におけるP波速度の代表値)
    L_ast = R0_ast/Δ        ## 代表長さ (波の代表波長)
    T_ast = L_ast/U_ast     ## 代表時間
    
    ## 無次元化
    pG0 = pG0_ast / (ρA_ast * U_ast^2)
    σ = σ_ast / (ρA_ast * U_ast^2 * R0_ast)
    μL = μL_ast / (ρA_ast * U_ast * L_ast)
    μP = μL * (1 - φP/φm)^(-2)

    ## 減衰係数の計算
    θ⁺ = zeros(Complex{Float64},length(k))
    θ⁻ = zeros(Complex{Float64},length(k))
    for i in [1:length(k);]
        a2 = Δ^2*k[i]^2 + 3α0*(1-α0)
        a1 = 4μP * ( 1 + α0*(1-α0) ) * k[i]^2
        a0 = (3κ*pG0 - 2σ) * k[i]^2
        θ⁺[i] = ( -a1 + sqrt( complex( a1^2 - 4a2*a0 ) ) ) / (2a2)
        θ⁻[i] = ( -a1 - sqrt( complex( a1^2 - 4a2*a0 ) ) ) / (2a2)
    end

    if φP/φm < 0.5
        return [real(θ⁺), real(θ⁻), imag(θ⁺), imag(θ⁻)]
    else
        println("Our of Assumptions!!")
    end
end

#Dispersion(3, 0.05, 0.5, 10^2, 0.04, 2, 0.01, 0.3)

















