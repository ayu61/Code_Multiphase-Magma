using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"
include("coefficients_mixture.jl")
include("coefficients_TFM.jl")

function MixtureCoeffPlot_void(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.1;]
    Π1 = zeros(2,length(α0))
    Π2 = zeros(2,length(α0))
    Π3 = zeros(2,length(α0))

    for i in [1:length(α0);]
        ## Mixture model
        Π1[1,i] = MixtureCoeff(α0[i], R0mm_ast, μL_ast, φP, rp)[1]
        Π2[1,i] = -MixtureCoeff(α0[i], R0mm_ast, μL_ast, φP, rp)[2]
        Π3[1,i] = MixtureCoeff(α0[i], R0mm_ast, μL_ast, φP, rp)[3]

        ## Effective Two-fluid model
        Π1[2,i] = TFMCoeff(α0[i], R0mm_ast, μL_ast, φP, rp)[1]
        Π2[2,i] = -TFMCoeff(α0[i], R0mm_ast, μL_ast, φP, rp)[2]
        Π3[2,i] = TFMCoeff(α0[i], R0mm_ast, μL_ast, φP, rp)[3]
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legendfontsize = 14,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt1 = plot(α0, Π1[1,:],
        color = "black",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{M}1} / s_{\mathrm{M}3}$",
        legend = :topleft,
        ylabel = L"Nonlinear coefficient $[-]$",
    )
    plt1 = plot!(α0, Π1[2,:],
        color = "red",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{E}1} / s_{\mathrm{E}4}$",
    )

    plt2 = plot(α0, Π2[1,:],
        color = "black",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{M}2}$",
        legend = :bottomleft,
        ylabel = L"Dissipation coefficient $[-]$",
    )
    plt2 = plot!(α0, Π2[2,:],
        color = "red",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{E}2}$",
    )

    plt3 = plot(α0, Π3[1,:],
        color = "black",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{M}3}$",
        ylabel = L"Dispersion coefficient $[-]$",
        legend = :bottomleft,
    )
    plt3 = plot!(α0, Π3[2,:],
        color = "red",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{E}3}$",
    )

    savefig(plt1, "./KdVB_scripts/Coefficients_plot/Pi1_void.pdf")
    savefig(plt2, "./KdVB_scripts/Coefficients_plot/Pi2_void.pdf")
    savefig(plt3, "./KdVB_scripts/Coefficients_plot/Pi3_void.pdf")
end

function MixtureCoeffPlot_phiP(α0, R0mm_ast, μL_ast, rp)
    φP = [0.001: 0.0001: 0.2;]
    Π1 = zeros(2,length(φP))
    Π2 = zeros(2,length(φP))
    Π3 = zeros(2,length(φP))

    for i in [1:length(φP);]
        ## Mixture model
        Π1[1,i] = MixtureCoeff(α0, R0mm_ast, μL_ast, φP[i], rp)[1]
        Π2[1,i] = -MixtureCoeff(α0, R0mm_ast, μL_ast, φP[i], rp)[2]
        Π3[1,i] = MixtureCoeff(α0, R0mm_ast, μL_ast, φP[i], rp)[3]

        ## Effective Two-fluid model
        Π1[2,i] = TFMCoeff(α0, R0mm_ast, μL_ast, φP[i], rp)[1]
        Π2[2,i] = -TFMCoeff(α0, R0mm_ast, μL_ast, φP[i], rp)[2]
        Π3[2,i] = TFMCoeff(α0, R0mm_ast, μL_ast, φP[i], rp)[3]
    end

    default(
        xlabel = L"$\phi_\mathrm{P} \,[-]$",
        xscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legendfontsize = 14,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt1 = plot(φP, Π1[1,:],
        color = "black",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{M}1} / s_{\mathrm{M}3}$",
        legend = false,#:topleft,
        ylabel = L"$C_1$ $[-]$",
        ylim = (0.5, 1.5),
    )
    #plt1 = plot!(φP, Π1[2,:],
    #    color = "red",
    #    linestyle = :solid,
    #    label = L"$\varPi_{\mathrm{E}1} / s_{\mathrm{E}4}$",
    #)

    plt2 = plot(φP, Π2[1,:],
        color = "black",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{M}2}$",
        legend = false,#:bottomleft,
        ylabel = L"$C_2$ $[-]$",
    )
    #plt2 = plot!(φP, Π2[2,:],
    #    color = "red",
    #    linestyle = :solid,
    #    label = L"$\varPi_{\mathrm{E}2}$",
    #)

    plt3 = plot(φP, Π3[1,:],
        color = "black",
        linestyle = :solid,
        label = L"$\varPi_{\mathrm{M}3}$",
        ylabel = L"$C_3$ $[-]$",
        legend = false,#:bottomleft,
        ylim = (0.3, 0.7),
    )
    #plt3 = plot!(φP, Π3[2,:],
    #    color = "red",
    #    linestyle = :solid,
    #    label = L"$\varPi_{\mathrm{E}3}$",
    #)

    savefig(plt1, "./KdVB_scripts/Coefficients_plot/Pi1_phiP.pdf")
    savefig(plt2, "./KdVB_scripts/Coefficients_plot/Pi2_phiP.pdf")
    savefig(plt3, "./KdVB_scripts/Coefficients_plot/Pi3_phiP.pdf")
end


function CoeffPlot_R0_Pi3(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π2 = zeros(2, length(R0mm_ast), length(α0))

    for r in [1:length(R0mm_ast);]
        for a in [1:length(α0);]
            Π2[1,r,a] = MixtureCoeff(α0[a], R0mm_ast[r], μL_ast, φP, rp)[3]
            Π2[2,r,a] = TFMCoeff(α0[a], R0mm_ast[r], μL_ast, φP, rp)[3]
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :topleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π2[1,1,:],
        color = "black",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$R_0^\ast = 0.1\,$mm",
    )

    plt = plot!(α0, Π2[1,2,:],
        color = "black",
        linestyle = :dash,
        label = L"$R_0^\ast = 0.5\,$mm",
    )

    plt = plot!(α0, Π2[1,3,:],
        color = "black",
        linestyle = :dot,
        label = L"$R_0^\ast = 1.0\,$mm",
    )


    plt = plot!(α0, Π2[2,1,:],
        color = "red",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$R_0^\ast = 0.1\,$mm",
    )

    plt = plot!(α0, Π2[2,2,:],
        color = "red",
        linestyle = :dash,
        label = L"$R_0^\ast = 0.5\,$mm",
    )

    plt = plot!(α0, Π2[2,3,:],
        color = "red",
        linestyle = :dot,
        label = L"$R_0^\ast = 1.0\,$mm",
    )

    savefig(plt, "./KdVB_scripts/Coefficients_plot/Pi3_R0.pdf")
end


function CoeffPlot_R0_Pi2(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π2 = zeros(2, length(R0mm_ast), length(α0))

    for r in [1:length(R0mm_ast);]
        for a in [1:length(α0);]
            Π2[1,r,a] = -MixtureCoeff(α0[a], R0mm_ast[r], μL_ast, φP, rp)[2]
            Π2[2,r,a] = -TFMCoeff(α0[a], R0mm_ast[r], μL_ast, φP, rp)[2]
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :topleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π2[1,1,:],
        color = "black",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$R_0^\ast = 0.1\,$mm",
    )

    plt = plot!(α0, Π2[1,2,:],
        color = "black",
        linestyle = :dash,
        label = L"$R_0^\ast = 0.5\,$mm",
    )

    plt = plot!(α0, Π2[1,3,:],
        color = "black",
        linestyle = :dot,
        label = L"$R_0^\ast = 1.0\,$mm",
    )


    plt = plot!(α0, Π2[2,1,:],
        color = "red",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$R_0^\ast = 0.1\,$mm",
    )

    plt = plot!(α0, Π2[2,2,:],
        color = "red",
        linestyle = :dash,
        label = L"$R_0^\ast = 0.5\,$mm",
    )

    plt = plot!(α0, Π2[2,3,:],
        color = "red",
        linestyle = :dot,
        label = L"$R_0^\ast = 1.0\,$mm",
    )

    savefig(plt, "./KdVB_scripts/Coefficients_plot/Pi2_R0.pdf")
end


function CoeffPlot_phi(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π2 = zeros(2, length(φP), length(α0))

    for p in [1:length(φP);]
        for a in [1:length(α0);]
            Π2[1,p,a] = -MixtureCoeff(α0[a], R0mm_ast, μL_ast, φP[p], rp)[2]
            Π2[2,p,a] = -TFMCoeff(α0[a], R0mm_ast, μL_ast, φP[p], rp)[2]
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :bottomleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π2[1,1,:],
        color = "black",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$\phi_\mathrm{P} = 0.01$",
    )

    plt = plot!(α0, Π2[1,2,:],
        color = "black",
        linestyle = :dash,
        label = L"$\phi_\mathrm{P} = 0.05$",
    )

    plt = plot!(α0, Π2[1,3,:],
        color = "black",
        linestyle = :dot,
        label = L"$\phi_\mathrm{P} = 0.10$",
    )


    plt = plot!(α0, Π2[2,1,:],
        color = "red",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$\phi_\mathrm{P} = 0.01$",
    )

    plt = plot!(α0, Π2[2,2,:],
        color = "red",
        linestyle = :dash,
        label = L"$\phi_\mathrm{P} = 0.05$",
    )

    plt = plot!(α0, Π2[2,3,:],
        color = "red",
        linestyle = :dot,
        label = L"$\phi_\mathrm{P} = 0.10$",
    )

    savefig(plt, "./KdVB_scripts/Coefficients_plot/Pi2_phi.pdf")
end


function CoeffPlot_vis(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π2 = zeros(2, length(μL_ast), length(α0))

    for p in [1:length(μL_ast);]
        for a in [1:length(α0);]
            Π2[1,p,a] = -MixtureCoeff(α0[a], R0mm_ast, μL_ast[p], φP, rp)[2]
            Π2[2,p,a] = -TFMCoeff(α0[a], R0mm_ast, μL_ast[p], φP, rp)[2]
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = (0.15,0.7),
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π2[1,1,:],
        color = "black",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$\mu_\mathrm{L}^\ast = 10^1\,$Pas",
    )

    plt = plot!(α0, Π2[1,2,:],
        color = "black",
        linestyle = :dash,
        label = L"$\mu_\mathrm{L}^\ast = 10^2\,$Pas",
    )

    plt = plot!(α0, Π2[1,3,:],
        color = "black",
        linestyle = :dot,
        label = L"$\mu_\mathrm{L}^\ast = 10^3\,$Pas",
    )


    plt = plot!(α0, Π2[2,1,:],
        color = "red",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$\mu_\mathrm{L}^\ast = 10^1\,$Pas",
    )

    plt = plot!(α0, Π2[2,2,:],
        color = "red",
        linestyle = :dash,
        label = L"$\mu_\mathrm{L}^\ast = 10^2\,$Pas",
    )

    plt = plot!(α0, Π2[2,3,:],
        color = "red",
        linestyle = :dot,
        label = L"$\mu_\mathrm{L}^\ast = 10^3\,$Pas",
    )

    savefig(plt, "./KdVB_scripts/Coefficients_plot/Pi2_vis.pdf")
end


function CoeffPlot_rP(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π2 = zeros(2, length(rp), length(α0))

    for p in [1:length(rp);]
        for a in [1:length(α0);]
            Π2[1,p,a] = -MixtureCoeff(α0[a], R0mm_ast, μL_ast, φP, rp[p])[2]
            Π2[2,p,a] = -TFMCoeff(α0[a], R0mm_ast, μL_ast, φP, rp[p])[2]
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :bottomleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π2[1,1,:],
        color = "black",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$r_\mathrm{P} = 2$",
    )

    plt = plot!(α0, Π2[1,2,:],
        color = "black",
        linestyle = :dash,
        label = L"$r_\mathrm{P} = 5$",
    )

    plt = plot!(α0, Π2[1,3,:],
        color = "black",
        linestyle = :dot,
        label = L"$r_\mathrm{P} = 10$",
    )


    plt = plot!(α0, Π2[2,1,:],
        color = "red",
        ylabel = "Dissipation coefficient",
        linestyle = :solid,
        label = L"$r_\mathrm{P} = 2$",
    )

    plt = plot!(α0, Π2[2,2,:],
        color = "red",
        linestyle = :dash,
        label = L"$r_\mathrm{P} = 5$",
    )

    plt = plot!(α0, Π2[2,3,:],
        color = "red",
        linestyle = :dot,
        label = L"$r_\mathrm{P} = 10$",
    )

    savefig(plt, "./KdVB_scripts/Coefficients_plot/Pi2_rP.pdf")
end



function CoeffPlot_U(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    U = zeros(2,length(α0))

    for a in [1:length(α0);]
        U[1,a] = MixtureCoeff(α0[a], R0mm_ast, μL_ast, φP, rp)[4]
        U[2,a] = TFMCoeff(α0[a], R0mm_ast, μL_ast, φP, rp)[4]
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :topright,
        legendfontsize = 14,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, U[1,:],
        color = "black",
        ylabel = "Representative velocity [m/s]",
        linestyle = :solid,
        label = L"$U^\ast_\mathrm{M}\,$",
    )

    plt = plot!(α0, U[2,:],
        color = "red",
        linestyle = :solid,
        label = L"$U^\ast_\mathrm{E}\,$",
    )

    savefig(plt, "./KdVB_scripts/Coefficients_plot/U_ast.pdf")
end

#CoeffPlot_R0_Pi3([0.1,0.5, 1.0], 10^2, 0.04, 2)
#CoeffPlot_R0_Pi2([0.1,0.5, 1.0], 10^2, 0.04, 2)

#CoeffPlot_phi(0.5, 10^2, [0.01, 0.05, 0.1], 2)
#CoeffPlot_vis(0.5, [10, 10^2, 10^3], 0.04, 2)
#CoeffPlot_rP(0.5, 10^2, 0.04, [2, 5, 10])

#CoeffPlot_U(0.5, 10^2, 0.04, 2)

#MixtureCoeffPlot_void(0.5, 10^2, 0.04, 2)
MixtureCoeffPlot_phiP(0.05, 0.5, 10^2, 2)