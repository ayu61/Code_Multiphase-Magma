## $julia --threads [number of threads]
## julia> include("KdVB.jl")


using LinearAlgebra
using Plots;gr()
plot_font = "Computer Modern"
using LaTeXStrings
using FFTW
using ProgressMeter
using Base.Threads
include("coefficients_mixture.jl")
include("coefficients_TFM.jl")

## calculation settings
dt = 10^(-3)  ## time step
nx = 2^10   ## divide number of space
interval_n = 0.2    ## plot each t=interval_n
interval = floor(Int, floor(Int, 1/dt)*interval_n )
t_max = 50  ## maximum value of t
x_max = 4π  ## calculation domain

## initial waveform
scale = 10^(-4)
x = [0:x_max/(nx-1):x_max;]
u_0 = sin.(x)*scale
#u_0 = [sech.(x[i]-4)^2 for i in [1:length(x);]]

## wave number
function GetWaveNum(i)
    if i <= nx/2
        return (2π/x_max)*(i-1)
    else
        return (2π/x_max)*(i-1-nx)
    end
end

## 2/3 rule
function TwoThirdsRule(nl_F)
    max_k = floor(Int, nx/2)
    @threads for i in [1:max_k;]
        if i >= max_k*2/3
            nl_F[i] = 0
        end
    end
end

## linear operator (dissipation and dispersion terms)
function Linear(data_F, Π2, Π3)
    datalen_origin = length(data_F)
    data_F = rfft(data_F)
    TwoThirdsRule(data_F)
    @threads for i in [1:floor(Int, nx/2+1);]
        k = GetWaveNum(i)
        data_F[i] = exp(Π2*dt/2) * exp(im*k^3*Π3*dt/2) * data_F[i]
    end
    return irfft(data_F, datalen_origin)
end

## nonlinear operator (nonlinear term)
function AFunction(data_F, Π1)
    datalen_origin = length(data_F)
    data_F = rfft(data_F.^2)
    @threads for i in [1:floor(Int, nx/2+1);]
        k = GetWaveNum(i)
        data_F[i] = -im*k*Π1/2*data_F[i]
    end
    return irfft(data_F, datalen_origin)
end

function Nonlinear(data_F, Π1)
    k1 = AFunction(data_F, Π1)
    k2 = AFunction(data_F + dt/2*k1, Π1)
    k3 = AFunction(data_F + dt/2*k2, Π1)
    k4 = AFunction(data_F + dt*k3, Π1)
    data_F += dt/6 * (k1 + 2k2 + 2k3 + k4)
    return data_F
end

## main
function KdVB(α0, R0mm_ast, μL_ast, φP, rp)
    ## coefficients
    Π1_1 = TFMCoeff(α0, R0mm_ast[1], μL_ast, φP, rp)[1]
    Π2_1 = TFMCoeff(α0, R0mm_ast[1], μL_ast, φP, rp)[2]
    Π3_1 = TFMCoeff(α0, R0mm_ast[1], μL_ast, φP, rp)[3]

    Π1_2 = TFMCoeff(α0, R0mm_ast[2], μL_ast, φP, rp)[1]
    Π2_2 = TFMCoeff(α0, R0mm_ast[2], μL_ast, φP, rp)[2]
    Π3_2 = TFMCoeff(α0, R0mm_ast[2], μL_ast, φP, rp)[3]

    Π1_3 = TFMCoeff(α0, R0mm_ast[3], μL_ast, φP, rp)[1]
    Π2_3 = TFMCoeff(α0, R0mm_ast[3], μL_ast, φP, rp)[2]
    Π3_3 = TFMCoeff(α0, R0mm_ast[3], μL_ast, φP, rp)[3]

    ## making directories
    dictname = "./KdVB_scripts/waveform/R0_dep/"*string(α0)*"_"*string(R0mm_ast)*"_"*string(μL_ast)*"_"*string(φP)*"_"*string(rp)*"/"
    dictname_waveforms = "./KdVB_scripts/waveform/R0_dep/"*string(α0)*"_"*string(R0mm_ast)*"_"*string(μL_ast)*"_"*string(φP)*"_"*string(rp)*"/waveforms/"
    if isdir(dictname) == false
        mkdir(dictname)
        mkdir(dictname_waveforms)
    end

    fh = open(dictname * "/wave_data.txt", "w")

    u1 = u_0
    u2 = u_0
    u3 = u_0

    default(
        xlabel = L"$\xi$",
        ylabel = L"$p_{\mathrm{A}1} \times 10^{-4}$",
        framestyle = :box,
        legend = :bottomright,
        linewidth = 3,
        size = (900,600),
        tickfontsize = 18,
        guidefontsize = 18,
        titlefontsize = 18,
        labelfontsize = 20,
        legendfontsize = 14,
        fontfamily = plot_font,
        #foreground_color_legend = nothing,
        #background_color_legend = nothing,
        ylim = (-1.1*scale, 1.1*scale),
        yticks = ([-0.0001, -0.00005, 0, 0.00005, 0.0001],[-1.0, -0.5, 0, 0.5, 1.0]),
        leftmargin = 0.5Plots.cm,
    )
    anim = Animation()

    plt = plot(x,u1,
        title = L"$\tau = 0$",
        color = "black",
        linestyle = :solid,
        label = L"$R_0^\ast = 0.1\,$mm",
    )
    plt = plot!(x,u2,
        title = L"$\tau = 0$",
        color = "black",
        linestyle = :dash,
        label = L"$R_0^\ast = 0.5\,$mm",
    )
    plt = plot!(x,u3,
        title = L"$\tau = 0$",
        color = "black",
        linestyle = :dot,
        label = L"$R_0^\ast = 1.0\,$mm",
    )
    savefig(plt, dictname_waveforms*"image0.pdf")

    @showprogress for n in [1:floor(Int, t_max/dt);]
        if n % interval == 0
            ## generate waveform_data.txt
            for j in [1:length(u1)]
                write(fh, string(j) * " " * string(u1[j]) * "\n")
            end
            write(fh, "\n")

            ## generate waveform plot
            plt = plot(x,u1,
                title = L"$\tau = $" * string(round(dt*n,digits=1)),
                color = "black",
                label = L"$R_0^\ast = 0.1\,$mm",
                linestyle = :solid,
            )
            plt = plot!(x,u2,
                title = L"$\tau = $" * string(round(dt*n,digits=1)),
                color = "black",
                label = L"$R_0^\ast = 0.5\,$mm",
                linestyle = :dash,
            )
            plt = plot!(x,u3,
                title = L"$\tau = $" * string(round(dt*n,digits=1)),
                color = "black",
                label = L"$R_0^\ast = 1.0\,$mm",
                linestyle = :dot,
            )
            
            savefig(plt, dictname_waveforms*"image"*string(n)*".pdf")
            frame(anim, plt)
        end

        ## 2nd-order split step Fourier method
        L1_u1 = Linear(u1, Π2_1, Π3_1)
        N_u1 = Nonlinear(L1_u1, Π1_1)
        L2_u1 = Linear(N_u1, Π2_1, Π3_1)
        u1 = L2_u1

        L1_u2 = Linear(u2, Π2_2, Π3_2)
        N_u2 = Nonlinear(L1_u2, Π1_2)
        L2_u2 = Linear(N_u2, Π2_2, Π3_2)
        u2 = L2_u2

        L1_u3 = Linear(u3, Π2_3, Π3_3)
        N_u3 = Nonlinear(L1_u3, Π1_3)
        L2_u3 = Linear(N_u3, Π2_3, Π3_3)
        u3 = L2_u3
    end

    gif(anim, dictname*"/animation.gif", fps=10)
    close(fh)
    #exit()
end

KdVB(0.05, [0.1, 0.5, 1.0], 10^2, 0.04, 2)

#exit()