using LinearAlgebra

## coefficients of KdVB equation based on Mixture model
## _ast denotes a dimensional value
function TFMCoeff(α0, R0mm_ast, μL_ast, φP, rp)

    ## マグマの代表的なパラメータ
    ρA_ast = 2600       ## 結晶-メルト混合流体の密度 [kg/m³]
    σ_ast = 0.3     ## マグマの表面張力（含水率に応じて0.05~0.3に変化）

    ## 仮定 (気泡は球形・流れは定常・地下4km程度のマグマ溜まり条件)
    pA0_ast = 100*10^6      ## 実効媒質の圧力 [Pa]
    pG0_ast = pA0_ast + 2σ_ast      ## 気相の圧力 [Pa]
    R0_ast = R0mm_ast * 10^(-3)     ## 気泡半径 [m]
    κ = 1       ## ポリトロープ指数 [-]
    β1 = 0.5    ## 球形気泡の場合の付加質量係数 [-]
    β2 = 0.5    ## 球形気泡の場合の付加質量係数 [-]
    
    ## 実効粘度モデルのパラメータ
    φm = 0.55exp(-(log10(rp))^2/2)      ## Maximum packing fanction [-]

    ## 計算条件
    ϵ = 10^(-3)
    Ω = 1

    ## 気泡の固有振動数
    ωB_ast = sqrt(
        ( 3κ*(pA0_ast+2σ_ast/R0_ast) - 2σ_ast/R0_ast ) / (ρA_ast*R0_ast^2)
    )

    ## 代表値
    ω_ast = Ω*sqrt(ϵ)*ωB_ast        ## 代表角周波数
    U_ast = sqrt(
        ((1-α0+β1)*κ*pG0_ast) / (β1*(1-α0)*ρA_ast)
        + (R0_ast^2*ωB_ast^2) / (3α0)
    )        ## 代表速度
    T_ast = 1/ω_ast     ## 代表周期
    L_ast = U_ast*T_ast     ## 代表波長
    Δ = 0# R0_ast / (L_ast*sqrt(ϵ))

    ## 無次元化
    pG0 = pG0_ast / (ρA_ast*U_ast^2)
    pA0 = pA0_ast / (ρA_ast*U_ast^2)
    σ = σ_ast / (ρA_ast*U_ast^2*R0_ast)
    μL = μL_ast / (ρA_ast*U_ast*L_ast)
    μP = μL * (1 - φP/φm)^(-2)

    ## coefficients of first order perturbations
    s4 = -(3κ*pG0 - 2σ) / pA0 #-Δ^2 / (pA0*Ω^2)
    s3 = - (
        3κ*α0*pG0 - (1-α0)*pA0*s4
    ) / (1-α0)
    s1 = -(1-α0)/α0 * s3
    s2 = s1 - 3

    ## Nonlinear coefficient terms
    k1 = (6 - 3(s1-s2) + s1*s2)/ 3
    k2 = s1*s3/3
    kᵦ = (β1+β2)*s1*(s2-s3) - β1*(s2^2-s3^2)
    k3 = (1-α0+β1)/(6β1*(1-α0)) * (kᵦ + 3κ*(s1-3κ-1)*pG0)
    k4 = -1/(6α0*(1-α0)) * (
        α0*kᵦ + 2(1-α0)*s3^2 - 2α0*s1*s4*pA0 - α0*(3κ*pG0-2σ)*s1
    )
    k5 = -1/(3α0) * (3κ*(3κ+1)*pG0/2 - 2σ)

    ## coefficients of KdVB 
    Π1 = k1 + k2 + k3 + k4 + k5
    Π2 = -2μP/(3α0) * (
        1 - (
            α0*κ*pG0/(1-α0) + Δ^2/(3Ω^2)
        )
    )
    Π3 = Δ^2 / (6α0)

    return [Π1/s4, Π2, Π3, U_ast] 

end


#TFMCoeff(0.05, 0.5, 10^2, 0.04, 2)[1]
