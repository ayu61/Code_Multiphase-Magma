using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"
include("coefficients_mixture_Long.jl")
include("coefficients_TFM_Long.jl")

x_max = 4000
nx = 2^7
f2 = 10^(-4)

function SWSolution(ξ, τ, f2, Π1, Π2, ξ0)
    f = zeros(length(ξ))
    for i in [1:length(ξ);]
        f[i] = f2/(2) - f2/(2) * tanh(
            f2/(4Π2/Π1) * (
                ξ[i] - Π1*f2/2 * τ - ξ0
            )
        )
    end
    return f
end

function SWData(α0, R0mm_ast, μL_ast, φP, rp)
    ## 計算条件
    τ = [0, 20, 1000]
    ξ = [0:x_max/(nx-1):x_max;]

    ## 初期化
    fM = zeros(length(τ),length(ξ))
    fE = zeros(length(τ),length(ξ))

    for t in [1:length(τ);]
        ## Coefficients of Mixture model
        Π1_M = MixtureCoeff(α0, R0mm_ast, μL_ast, φP, rp)[1]
        Π2_M = -MixtureCoeff(α0, R0mm_ast, μL_ast, φP, rp)[2]

        ## Coefficients of Effective Two-fluid model
        Π1_E = TFMCoeff(α0, R0mm_ast, μL_ast, φP, rp)[1]
        Π2_E = -TFMCoeff(α0, R0mm_ast, μL_ast, φP, rp)[2]

        ## shock wave solution
        fM[t,:] = SWSolution(ξ, τ[t], f2, Π1_M, Π2_M, x_max/2)
        fE[t,:] = SWSolution(ξ, τ[t], f2, Π1_E, Π2_E, x_max/2)
    end

    return [fM, fE]

end




function PlotSW_model(α0,R0mm_ast,μL_ast,φP,rp)
    ξ = [0:x_max/(nx-1):x_max;]
    fM = SWData(α0,R0mm_ast,μL_ast,φP,rp)[1]
    fE = SWData(α0,R0mm_ast,μL_ast,φP,rp)[2]

    default(
        xlabel = L"$\xi$",
        ylabel = L"$p_{\mathrm{A}1} \times 10^{-4}$",
        legend = :bottomleft,
        linestyle = :solid,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legendfontsize = 12,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
        yticks = ([0, 0.000025, 0.00005, 0.000075, 0.0001],[0, 0.25,0.5, 0.75, 1.0]),
    )

    plt = plot(ξ, fM[1,:],
        label = "Mixture model",
        color = "black",
    )
    plt = plot!(ξ, fE[1,:],
        label = "Effective Two-fluid model",
        color = "black",
        linestyle = :dash,
    )
    savefig(plt, "./KdVB_scripts/shock_wave/model-dep_"*string(α0)*"_"*string(f2)*".pdf")
end


function PlotSW_void(α0, R0mm_ast, μL_ast, φP, rp)
    ξ = [0:x_max/(nx-1):x_max;]
    f = zeros(length(α0),length(ξ))

    for a in [1:length(α0);]
        f[a,:] = SWData(α0[a],R0mm_ast,μL_ast,φP,rp)[2][1,:]
    end

    default(
        xlabel = L"$\xi$",
        ylabel = L"$p_{\mathrm{A}1} \times 10^{-4}$",
        legend = :bottomleft,
        linestyle = :solid,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legendfontsize = 12,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
        yticks = ([0, 0.000025, 0.00005, 0.000075, 0.0001],[0, 0.25,0.5, 0.75, 1.0]),
        color = "black",
    )

    plt = plot(ξ, f[1,:],
        label = L"\alpha_0 = 0.001",
        linestyle = :solid,
    )
    plt = plot!(ξ, f[2,:],
        label = L"\alpha_0 = 0.01",
        linestyle = :dash,
    )
    plt = plot!(ξ, f[3,:],
        label = L"\alpha_0 = 0.1",
        linestyle = :dot,
    )
    
    savefig(plt, "./KdVB_scripts/shock_wave/void-dep_"*string(α0)*"_"*string(f2)*".pdf")
end


function PlotSW_R0(α0, R0mm_ast, μL_ast, φP, rp)
    ξ = [0:x_max/(nx-1):x_max;]
    f = zeros(length(R0mm_ast),length(ξ))

    for a in [1:length(R0mm_ast);]
        f[a,:] = SWData(α0,R0mm_ast[a],μL_ast,φP,rp)[2][1,:]
    end

    default(
        xlabel = L"$\xi$",
        ylabel = L"$p_{\mathrm{A}1} \times 10^{-4}$",
        legend = :bottomleft,
        linestyle = :solid,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legendfontsize = 12,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
        yticks = ([0, 0.000025, 0.00005, 0.000075, 0.0001],[0, 0.25,0.5, 0.75, 1.0]),
        color = "black",
    )

    plt = plot(ξ, f[1,:],
        label = L"$R_0^\ast = 0.1\,$mm",
        linestyle = :solid,
    )
    plt = plot!(ξ, f[2,:],
        label = L"$R_0^\ast = 0.5\,$mm",
        linestyle = :dash,
    )
    plt = plot!(ξ, f[3,:],
        label = L"$R_0^\ast = 1.0\,$mm",
        linestyle = :dot,
    )
    
    savefig(plt, "./KdVB_scripts/shock_wave/R0-dep_"*string(α0)*"_"*string(f2)*".pdf")
end



function dPlot_void_R(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π = zeros(2, length(R0mm_ast), length(α0))

    for r in [1:length(R0mm_ast);]
        for a in [1:length(α0);]
            Π[1,r,a] = -4*MixtureCoeff(α0[a], R0mm_ast[r], μL_ast, φP, rp)[2] / MixtureCoeff(α0[a], R0mm_ast[r], μL_ast, φP, rp)[1]
            Π[2,r,a] = -4*TFMCoeff(α0[a], R0mm_ast[r], μL_ast, φP, rp)[2] / TFMCoeff(α0[a], R0mm_ast[r], μL_ast, φP, rp)[1]
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :topleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π[1,1,:],
        color = "black",
        ylabel = L"$4 \varPi_2 / \varPi_1$",
        linestyle = :solid,
        label = L"$R_0^\ast = 0.1\,$mm",
    )

    plt = plot!(α0, Π[1,2,:],
        color = "black",
        linestyle = :dash,
        label = L"$R_0^\ast = 0.5\,$mm",
    )

    plt = plot!(α0, Π[1,3,:],
        color = "black",
        linestyle = :dot,
        label = L"$R_0^\ast = 1.0\,$mm",
    )


    plt = plot!(α0, Π[2,1,:],
        color = "red",
        linestyle = :solid,
        label = L"$R_0^\ast = 0.1\,$mm",
    )

    plt = plot!(α0, Π[2,2,:],
        color = "red",
        linestyle = :dash,
        label = L"$R_0^\ast = 0.5\,$mm",
    )

    plt = plot!(α0, Π[2,3,:],
        color = "red",
        linestyle = :dot,
        label = L"$R_0^\ast = 1.0\,$mm",
    )

    savefig(plt, "./KdVB_scripts/shock_wave/d_R.pdf")
end


function dPlot_void_vis(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π = zeros(2, length(μL_ast), length(α0))

    for r in [1:length(μL_ast);]
        for a in [1:length(α0);]
            Π[1,r,a] = -4*MixtureCoeff(α0[a], R0mm_ast, μL_ast[r], φP, rp)[2] / MixtureCoeff(α0[a], R0mm_ast, μL_ast[r], φP, rp)[1]
            Π[2,r,a] = -4*TFMCoeff(α0[a], R0mm_ast, μL_ast[r], φP, rp)[2] / TFMCoeff(α0[a], R0mm_ast, μL_ast[r], φP, rp)[1]
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :topleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π[1,1,:],
        color = "black",
        ylabel = L"$4 \varPi_2 / \varPi_1$",
        linestyle = :solid,
        label = L"$\mu_\mathrm{L}^\ast = 10^1\,$Pas",
    )

    plt = plot!(α0, Π[1,2,:],
        color = "black",
        linestyle = :dash,
        label = L"$\mu_\mathrm{L}^\ast = 10^2\,$Pas",
    )

    plt = plot!(α0, Π[1,3,:],
        color = "black",
        linestyle = :dot,
        label = L"$\mu_\mathrm{L}^\ast = 10^3\,$Pas",
    )


    plt = plot!(α0, Π[2,1,:],
        color = "red",
        linestyle = :solid,
        label = L"$\mu_\mathrm{L}^\ast = 10^1\,$Pas",
    )

    plt = plot!(α0, Π[2,2,:],
        color = "red",
        linestyle = :dash,
        label = L"$\mu_\mathrm{L}^\ast = 10^2\,$Pas",
    )

    plt = plot!(α0, Π[2,3,:],
        color = "red",
        linestyle = :dot,
        label = L"$\mu_\mathrm{L}^\ast = 10^3\,$Pas",
    )

    savefig(plt, "./KdVB_scripts/shock_wave/d_vis.pdf")
end



function dPlot_void_phi(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π = zeros(2, length(φP), length(α0))

    for r in [1:length(φP);]
        for a in [1:length(α0);]
            Π[1,r,a] = -4*MixtureCoeff(α0[a], R0mm_ast, μL_ast, φP[r], rp)[2] / MixtureCoeff(α0[a], R0mm_ast, μL_ast, φP[r], rp)[1]
            Π[2,r,a] = -4*TFMCoeff(α0[a], R0mm_ast, μL_ast, φP[r], rp)[2] / TFMCoeff(α0[a], R0mm_ast, μL_ast, φP[r], rp)[1]
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :bottomleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π[1,1,:],
        color = "black",
        ylabel = L"$4 \varPi_2 / \varPi_1$",
        linestyle = :solid,
        label = L"$\phi_\mathrm{P} = 0.01$",
    )

    plt = plot!(α0, Π[1,2,:],
        color = "black",
        linestyle = :dash,
        label = L"$\phi_\mathrm{P} = 0.05$",
    )

    plt = plot!(α0, Π[1,3,:],
        color = "black",
        linestyle = :dot,
        label = L"$\phi_\mathrm{P} = 0.10$",
    )


    plt = plot!(α0, Π[2,1,:],
        color = "red",
        linestyle = :solid,
        label = L"$\phi_\mathrm{P} = 0.01$",
    )

    plt = plot!(α0, Π[2,2,:],
        color = "red",
        linestyle = :dash,
        label = L"$\phi_\mathrm{P} = 0.05$",
    )

    plt = plot!(α0, Π[2,3,:],
        color = "red",
        linestyle = :dot,
        label = L"$\phi_\mathrm{P} = 0.10$",
    )

    savefig(plt, "./KdVB_scripts/shock_wave/d_phi.pdf")
end


function dPlot_void_model(R0mm_ast, μL_ast, φP, rp)
    α0 = [0.001: 0.0001: 0.3;]
    Π = zeros(2, length(α0))

    for r in [1:length(φP);]
        for a in [1:length(α0);]
            Π[1,a] = -4*MixtureCoeff(α0[a], R0mm_ast, μL_ast, φP[r], rp)[2] / MixtureCoeff(α0[a], R0mm_ast, μL_ast, φP[r], rp)[1] * 1/10^(-4)
            Π[2,a] = -4*TFMCoeff(α0[a], R0mm_ast, μL_ast, φP[r], rp)[2] / TFMCoeff(α0[a], R0mm_ast, μL_ast, φP[r], rp)[1] * 1/10^(-4)
        end
    end

    default(
        xlabel = L"$\alpha_0 \,[-]$",
        xscale = :log10,
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :bottomleft,
        legendfontsize = 12,
        fontfamily = plot_font,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(α0, Π[1,:],
        color = "black",
        ylabel = L"$d_\mathrm{S}\,[-]$",
        linestyle = :solid,
        label = "Mixture model",
    )

    plt = plot!(α0, Π[2,:],
        color = "black",
        linestyle = :dash,
        label = "Effective Two-fluid model",
    )

    savefig(plt, "./KdVB_scripts/shock_wave/d_model.pdf")
end


#PlotSW_model(0.05, 0.5, 10^2, 0.04, 2)
#PlotSW_void([0.001, 0.01, 0.1], 0.5, 10^2, 0.04, 2)
#PlotSW_R0(0.05, [0.1,0.5,1.0], 10^2, 0.04, 2)
#dPlot_void_R([0.1, 0.5, 1.0], 10^2, 0.04, 2)
#dPlot_void_vis(0.5, [10^1, 10^2, 10^3], 0.04, 2)
#dPlot_void_phi(0.5, 10^2, [0.01, 0.05, 0.10], 2)
dPlot_void_model(0.5, 10^2, 0.04, 2)