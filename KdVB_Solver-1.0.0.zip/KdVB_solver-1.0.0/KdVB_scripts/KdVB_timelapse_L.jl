## $julia --threads [number of threads]
## julia> include("KdVB.jl")


using LinearAlgebra
using Plots;gr()
plot_font = "Computer Modern"
using LaTeXStrings
using FFTW
using ProgressMeter
using Base.Threads
include("coefficients_mixture.jl")
include("coefficients_TFM.jl")

## calculation settings
dt = 10^(-3)  ## time step
nx = 2^10   ## divide number of space
interval_n = 12.0    ## plot each t=interval_n
interval = floor(Int, floor(Int, 1/dt)*interval_n )
t_max = interval_n*2  ## maximum value of t
x_max = 4π  ## calculation domain

## initial waveform
scale = 2
x = [0:x_max/(nx-1):x_max;]
u_0 = sin.(x)*scale
#u_0 = [sech.(x[i]-4)^2 for i in [1:length(x);]]

## wave number
function GetWaveNum(i)
    if i <= nx/2
        return (2π/x_max)*(i-1)
    else
        return (2π/x_max)*(i-1-nx)
    end
end

## 2/3 rule
function TwoThirdsRule(nl_F)
    max_k = floor(Int, nx/2)
    @threads for i in [1:max_k;]
        if i >= max_k*2/3
            nl_F[i] = 0
        end
    end
end

## linear operator (dissipation and dispersion terms)
function Linear(data_F, Π2, Π3)
    datalen_origin = length(data_F)
    data_F = rfft(data_F)
    TwoThirdsRule(data_F)
    @threads for i in [1:floor(Int, nx/2+1);]
        k = GetWaveNum(i)
        data_F[i] = exp(Π2*dt/2) * exp(im*k^3*Π3*dt/2) * data_F[i]
    end
    return irfft(data_F, datalen_origin)
end

## nonlinear operator (nonlinear term)
function AFunction(data_F, Π1)
    datalen_origin = length(data_F)
    data_F = rfft(data_F.^2)
    @threads for i in [1:floor(Int, nx/2+1);]
        k = GetWaveNum(i)
        data_F[i] = -im*k*Π1/2*data_F[i]
    end
    return irfft(data_F, datalen_origin)
end

function Nonlinear(data_F, Π1)
    k1 = AFunction(data_F, Π1)
    k2 = AFunction(data_F + dt/2*k1, Π1)
    k3 = AFunction(data_F + dt/2*k2, Π1)
    k4 = AFunction(data_F + dt*k3, Π1)
    data_F += dt/6 * (k1 + 2k2 + 2k3 + k4)
    return data_F
end

## main
function KdVB(α0, R0mm_ast, μL_ast, φP, rp)
    ## coefficients
    Π1 = TFMCoeff(α0, R0mm_ast, μL_ast, φP, rp)[1]
    Π2 = TFMCoeff(α0, R0mm_ast, μL_ast, φP, rp)[2]
    Π3 = TFMCoeff(α0, R0mm_ast, μL_ast, φP, rp)[3]
    U_ast = TFMCoeff(α0, R0mm_ast, μL_ast, φP, rp)[4]
    Uϵ = TFMCoeff(α0, R0mm_ast, μL_ast, φP, rp)[5]

    ## making directories
    dictname = "./KdVB_scripts/waveform/timelapse/"*string(α0)*"_"*string(R0mm_ast)*"_"*string(μL_ast)*"_"*string(φP)*"_"*string(rp)*"/"
    if isdir(dictname) == false
        mkdir(dictname)
    end

    u = u_0

    default(
        xlabel = L"$\xi$",
        ylabel = L"$p_{\mathrm{A}1}$",
        framestyle = :box,
        legend = (0.8, 0.96),
        linewidth = 3,
        size = (900,600),
        tickfontsize = 18,
        guidefontsize = 18,
        titlefontsize = 18,
        labelfontsize = 20,
        legendfontsize = 18,
        fontfamily = plot_font,
        ylim = (-1.1*scale, 1.5*scale),
        leftmargin = 0.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )


    plt = plot(x,u,
        label = L"$\tau = 0$",
        color = "black"
    )


    @showprogress for n in [1:floor(Int, t_max/dt);]
        if n % interval == 0

            ## generate waveform plot
            plt = plot!(x,u,
                label = L"$\tau = $" * string(round(dt*n,digits=1)),
                color = "black",
            )
        end

        ## 2nd-order split step Fourier method
        Linear_u_1 = Linear(u, Π2, Π3)
        Nonlinear_u = Nonlinear(Linear_u_1, Π1)
        Linear_u_2 = Linear(Nonlinear_u, Π2, Π3)
        u = Linear_u_2
    end
    savefig(plt, dictname*"timelapse_L.pdf")

end

KdVB(0.05, 0.5, 10^2, 0.04, 2)

#exit()