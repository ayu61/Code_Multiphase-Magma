using LinearAlgebra

## coefficients of KdVB equation based on Mixture model
## _ast denotes a dimensional value
function MixtureCoeff(α0, R0mm_ast, μL_ast, φP, rp)

    ## マグマの代表的なパラメータ
    ρA_ast = 2600       ## 結晶-メルト混合流体の密度 [kg/m³]
    σ_ast = 0.3     ## マグマの表面張力（含水率に応じて0.05~0.3に変化）

    ## 仮定 (気泡は球形・流れは定常・地下4km程度のマグマ溜まり条件)
    pA0_ast = 100*10^6      ## 実効媒質の圧力 [Pa]
    pG0_ast = pA0_ast + 2σ_ast      ## 気相の圧力 [Pa]
    R0_ast = R0mm_ast * 10^(-3)     ## 気泡半径 [m]
    κ = 1       ## ポリトロープ指数 [-]
    
    ## 実効粘度モデルのパラメータ
    φm = 0.55exp(-(log10(rp))^2/2)      ## Maximum packing fanction [-]

    ## 計算条件
    ϵ = 10^(-3)
    Ω = 1

    ## 気泡の固有振動数
    ωB_ast = sqrt(
        ( 3κ*(pA0_ast+2σ_ast/R0_ast) - 2σ_ast/R0_ast ) / (ρA_ast*R0_ast^2)
    )

    ## 代表値
    ω_ast = Ω*sqrt(ϵ)*ωB_ast        ## 代表角周波数
    U_ast = ωB_ast*R0_ast / sqrt(3α0*(1-α0))       ## 代表速度
    T_ast = 1/ω_ast     ## 代表周期
    L_ast = U_ast*T_ast     ## 代表波長
    Δ = R0_ast / (L_ast*sqrt(ϵ))

    ## 無次元化
    pG0 = pG0_ast / (ρA_ast*U_ast^2)
    pA0 = pA0_ast / (ρA_ast*U_ast^2)
    σ = σ_ast / (ρA_ast*U_ast^2*R0_ast)
    μL = μL_ast / (ρA_ast*U_ast*L_ast)
    μP = μL * (1 - φP/φm)^(-2)

    ## coefficients of first order perturbations
    s1 = 3(1-α0)
    s2 = -3α0
    s3 = s1*s2 / (3pA0)

    ## coefficients of KdVB 
    Π1 = 1/3 * (
        6 - 3s1 + 4s2 - α0*s1*s2/(1-α0) - s2^2/α0 
        - (
            3κ*(3κ+1)*pG0/2 - 2σ
        ) / (α0*(1-α0))
    )
    Π2 = -2μP/(3α0*(1-α0)) * (1 + α0*(1-α0))
    Π3 = Δ^2 / (6α0*(1-α0))

    return [Π1/s3, Π2, Π3, U_ast] 

end



