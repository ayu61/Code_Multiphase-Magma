using LinearAlgebra
using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"

## 引数一覧
# α0        ## 初期ボイド率 [-]
# φP        ## 実効媒質中における結晶の体積分率 [-] (固定値)
# R0mm_ast  ## 初期気泡半径 [mm]
# μL_ast    ## メルト粘度 [Pas]
# rp        ## アスペクト比 [-]
# Δ         ## 代表長さ(波の代表波長)に対する気泡半径の比
# σ_ast     ## 表面張力 [N/m] (含水率により0.05~0.3の値を取りうる)


function Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, φP2, rp2, Δ, σ_ast)

    ## マグマの代表的なパラメータ
    ρA_ast = 2600       ## 実効媒質の密度 [kg/m³]
    Kb = 20*10^9        ## 体積弾性率 [Pa]
    Kr = 10^4*10^6      ## 剛性率 [Pa]

    ## 仮定 (気泡は球形・流れは定常・地下4km程度のマグマ溜まり条件)
    pA0_ast = 100*10^6      ## 実効媒質の圧力 [Pa]
    pG0_ast = pA0_ast + 2σ_ast      ## 気相の圧力 [Pa]
    R0_ast = R0mm_ast * 10^(-3)     ## 気泡半径 [m]
    κ = 1       ## ポリトロープ指数 [-]
    β1 = 0.5    ## 球形気泡の場合の付加質量係数 [-]
    
    ## 実効粘度モデルのパラメータ
    φm1 = 0.55exp(-(log10(rp1))^2/2)      ## Maximum packing fanction [-]
    φm2 = 0.55exp(-(log10(rp2))^2/2)      ## Maximum packing fanction [-]
    
    ## 代表値
    U_ast = sqrt( (Kb + 4/3 * Kr) / ρA_ast )        ## 代表速度 (マグマ中におけるP波速度の代表値)
    L_ast = R0_ast/Δ        ## 代表長さ (波の代表波長)
    T_ast = L_ast/U_ast     ## 代表時間
    
    ## 無次元化
    pG0 = pG0_ast / (ρA_ast * U_ast^2)
    σ = σ_ast / (ρA_ast * U_ast^2 * R0_ast)
    μL = μL_ast / (ρA_ast * U_ast * L_ast)
    φmicro = φP2 / (1 - φP1)
    μP = μL * (1 - φP1/φm1)^(-2) * (1 - φmicro/φm2)^(-2)

    ## 減衰係数の計算(カルダノの公式)
    θ1 = zeros(Complex{Float64},length(k))
    θ2 = zeros(Complex{Float64},length(k))
    θ3 = zeros(Complex{Float64},length(k))

    for i in [1:length(k);]

        b3 = (1-α0) * (Δ^2*k[i]^2 + 3α0)
        b2 = 4(1-α0^2)*μP*k[i]^2
        b1 = ( 3κ*(α0*(1-α0) + β1)*pG0 - 2β1*(1-α0)*σ )*k[i]^2 / β1
        b0 = 4κ*α0*(1-α0)*pG0*μP*k[i]^4 / β1

        K1 = -2b2^3 + 9b1*b2*b3 - 27b0*b3^2
        K4 = -b2^2 + 3b1*b3
        K3 = K1^2 + 4*K4^3
        K2 = K1 + sqrt(Complex(K3))

        θ1[i] = -b2/(3b3) + K2^(1/3) / (3b3*2^(1/3)) - K4*2^(1/3) / (3b3*K2^(1/3))
        θ2[i] = -b2/(3b3) - (1-im*sqrt(3))*K2^(1/3) / (6b3*2^(1/3)) + (1+im*sqrt(3))*K4 / (3b3*2^(2/3)*K2^(1/3))
        θ3[i] = -b2/(3b3) - (1+im*sqrt(3))*K2^(1/3) / (6b3*2^(1/3)) + (1-im*sqrt(3))*K4 / (3b3*2^(2/3)*K2^(1/3))
    end

    if φP2/φm2 < 0.5
        return [real(θ1), real(θ2), real(θ3), imag(θ1), imag(θ2), imag(θ3)]
    else
        println("Our of Assumptions!!")
    end
end


function PhaseVelo_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, rp2, Δ, σ_ast)
    Imθ_1 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0, rp2, Δ, σ_ast)[5]
    Imθ_2 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.05, rp2, Δ, σ_ast)[5]
    Imθ_3 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.10, rp2, Δ, σ_ast)[5]
    Imθ_4 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.15, rp2, Δ, σ_ast)[5]

    vp1 = zeros(length(k))
    vp2 = zeros(length(k))
    vp3 = zeros(length(k))
    vp4 = zeros(length(k))
    for i in [1:length(k);]
        vp1[i] = abs(Imθ_1[i]) / k[i]
        vp2[i] = abs(Imθ_2[i]) / k[i]
        vp3[i] = abs(Imθ_3[i]) / k[i]
        vp4[i] = abs(Imθ_4[i]) / k[i]
    end

    Reθ⁺_1 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0, rp2, Δ, σ_ast)[2]
    Reθ⁻_1 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0, rp2, Δ, σ_ast)[3]

    Reθ⁺_2 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.05, rp2, Δ, σ_ast)[2]
    Reθ⁻_2 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.05, rp2, Δ, σ_ast)[3]

    Reθ⁺_3 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.10, rp2, Δ, σ_ast)[2]
    Reθ⁻_3 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.10, rp2, Δ, σ_ast)[3]

    Reθ⁺_4 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.15, rp2, Δ, σ_ast)[2]
    Reθ⁻_4 = Dispersion_cd_TFM(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.15, rp2, Δ, σ_ast)[3]

    plt = default(
        xlabel = L"Wave number $[-]$",
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :bottomleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(k, vp1, 
        color="black", 
        linestyle = :solid,
        label=L"$\phi_\mathrm{P_2} = 0$",
        ylim = (0.23, 0.29001),
        ylabel = L"$v_\mathrm{p} \,[-]$",
    )
    plt = plot!(k, vp2, 
        color="black", 
        linestyle = :dash,
        label=L"$\phi_\mathrm{P_2} = 0.05$"
    )
    plt = plot!(k, vp3, 
        color="black", 
        linestyle = :dot,
        label=L"$\phi_\mathrm{P_2} = 0.10$"
    )
    plt = plot!(k, vp4, 
        color="black", 
        linestyle = :dashdot,
        label=L"$\phi_\mathrm{P_2} = 0.15$"
    )

    plt = plot!(twinx(), k, [Reθ⁺_1, Reθ⁻_1],
        color = "red",
        linestyle = :solid,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-1.5, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_2, Reθ⁻_2],
        color = "red",
        linestyle = :dash,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-1.5, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_3, Reθ⁻_3],
        color = "red",
        linestyle = :dot,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-1.5, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_4, Reθ⁻_4],
        color = "red",
        linestyle = :dashdot,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-1.5, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )

    savefig("./scripts_compare/fig/crystal_dip_TFM.pdf")
end



PhaseVelo_cd_TFM([0.01:0.01:10;], 0.05, 0.5, 10^2, 0.04, 2, 8.3, 0.01, 0.3)




















