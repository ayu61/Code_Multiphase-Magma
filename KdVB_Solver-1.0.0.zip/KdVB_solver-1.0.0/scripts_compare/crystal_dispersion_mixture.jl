using LinearAlgebra
using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"

## 引数一覧
# α0        ## 初期ボイド率 [-]
# φP        ## 実効媒質中における結晶の体積分率 [-] (固定値)
# R0mm_ast  ## 初期気泡半径 [mm]
# μL_ast    ## メルト粘度 [Pas]
# rp        ## アスペクト比 [-]
# Δ         ## 代表長さ(波の代表波長)に対する気泡半径の比
# σ_ast     ## 表面張力 [N/m] (含水率により0.05~0.3の値を取りうる)

function Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, φP2, rp2, Δ, σ_ast)

    ## マグマの代表的なパラメータ
    ρA_ast = 2600       ## 実効媒質の密度 [kg/m³]
    Kb = 20*10^9        ## 体積弾性率 [Pa]
    Kr = 10^4*10^6      ## 剛性率 [Pa]

    ## 仮定 (気泡は球形・流れは定常・地下4km程度のマグマ溜まり条件)
    pA0_ast = 100*10^6      ## 実効媒質の圧力 [Pa]
    pG0_ast = pA0_ast + 2σ_ast      ## 気相の圧力 [Pa]
    R0_ast = R0mm_ast * 10^(-3)     ## 気泡半径 [m]
    κ = 1       ## ポリトロープ指数 [-]
    Ca = 0.001       ## Capillary数 [-] (小さいと仮定)
    Cd = 0.001       ## Dynamic capillary数 [-] (小さいと仮定)
    Cx = sqrt(Ca^2 + Cd^2)      ## Capillarity
    
    ## 実効粘度モデルのパラメータ
    φm1 = 0.55exp(-(log10(rp1))^2/2)      ## Maximum packing fanction [-]
    φm2 = 0.55exp(-(log10(rp2))^2/2)      ## Maximum packing fanction [-]
    λ0_ast = μL_ast*R0_ast/σ_ast     ## 緩和時間 [s]
    dγ_ast = Ca/λ0_ast      ## ひずみ速度 [m/s] (初期気泡半径のみによって決まる定数)
    ddγ_ast = Cd*dγ_ast/λ0_ast      ## ひずみ加速度 [m/s²] (初期気泡半径のみによって決まる定数)
    
    ## 代表値
    U_ast = sqrt( (Kb + 4/3 * Kr) / ρA_ast )        ## 代表速度 (マグマ中におけるP波速度の代表値)
    L_ast = R0_ast/Δ        ## 代表長さ (波の代表波長)
    T_ast = L_ast/U_ast     ## 代表時間
    
    ## 無次元化
    pG0 = pG0_ast / (ρA_ast * U_ast^2)
    σ = σ_ast / (ρA_ast * U_ast^2 * R0_ast)
    ca = μL_ast * dγ_ast * R0_ast / σ_ast
    cd = μL_ast * ddγ_ast * R0_ast / (σ_ast * dγ_ast)
    cx = sqrt(ca^2 + cd^2)
    μL = μL_ast / (ρA_ast * U_ast * L_ast)
    φmicro = φP2 / (1 - φP1)
    μP = μL * (1 - φP1/φm1)^(-2) * (1 - φmicro/φm2)^(-2)

    ## 減衰係数の計算
    θ⁺ = zeros(Complex{Float64},length(k))
    θ⁻ = zeros(Complex{Float64},length(k))
    for i in [1:length(k);]
        a2 = Δ^2*k[i]^2 + 3α0*(1-α0)
        a1 = 4μP * ( (6-2*cx^2)*α0 / (3(1+cx^2)) + 1 ) * k[i]^2
        a0 = (3κ*pG0 - 2σ) * k[i]^2
        θ⁺[i] = ( -a1 + sqrt( complex( a1^2 - 4a2*a0 ) ) ) / (2a2)
        θ⁻[i] = ( -a1 - sqrt( complex( a1^2 - 4a2*a0 ) ) ) / (2a2)
    end

    if φP2/φm2 < 0.5
        return [real(θ⁺), real(θ⁻), imag(θ⁺), imag(θ⁻)]
    else
        println("Our of Assumptions!!")
    end
end

function PhaseVelo_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, rp2, Δ, σ_ast)
    Imθ_1 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0, rp2, Δ, σ_ast)[4]
    Imθ_2 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.05, rp2, Δ, σ_ast)[4]
    Imθ_3 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.10, rp2, Δ, σ_ast)[4]
    Imθ_4 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.15, rp2, Δ, σ_ast)[4]

    vp1 = zeros(length(k))
    vp2 = zeros(length(k))
    vp3 = zeros(length(k))
    vp4 = zeros(length(k))
    for i in [1:length(k);]
        vp1[i] = abs(Imθ_1[i]) / k[i]
        vp2[i] = abs(Imθ_2[i]) / k[i]
        vp3[i] = abs(Imθ_3[i]) / k[i]
        vp4[i] = abs(Imθ_4[i]) / k[i]
    end

    Reθ⁺_1 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0, rp2, Δ, σ_ast)[1]
    Reθ⁻_1 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0, rp2, Δ, σ_ast)[2]

    Reθ⁺_2 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.05, rp2, Δ, σ_ast)[1]
    Reθ⁻_2 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.05, rp2, Δ, σ_ast)[2]

    Reθ⁺_3 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.10, rp2, Δ, σ_ast)[1]
    Reθ⁻_3 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.10, rp2, Δ, σ_ast)[2]

    Reθ⁺_4 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.15, rp2, Δ, σ_ast)[1]
    Reθ⁻_4 = Dispersion_cd_mixture(k, α0, R0mm_ast, μL_ast, φP1, rp1, 0.15, rp2, Δ, σ_ast)[2]

    plt = default(
        xlabel = L"Wave number $[-]$",
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = :bottomleft,
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(k, vp1, 
        color="black", 
        linestyle = :solid,
        label=L"$\phi_\mathrm{P_2} = 0$",
        ylim = (0.21, 0.27001),
        ylabel = L"$v_\mathrm{p} \,[-]$",
    )
    plt = plot!(k, vp2, 
        color="black", 
        linestyle = :dash,
        label=L"$\phi_\mathrm{P_2} = 0.05$"
    )
    plt = plot!(k, vp3, 
        color="black", 
        linestyle = :dot,
        label=L"$\phi_\mathrm{P_2} = 0.10$"
    )
    plt = plot!(k, vp4, 
        color="black", 
        linestyle = :dashdot,
        label=L"$\phi_\mathrm{P_2} = 0.15$"
    )

    plt = plot!(twinx(), k, [Reθ⁺_1, Reθ⁻_1],
        color = "red",
        linestyle = :solid,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-1.5, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_2, Reθ⁻_2],
        color = "red",
        linestyle = :dash,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-1.5, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_3, Reθ⁻_3],
        color = "red",
        linestyle = :dot,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-1.5, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_4, Reθ⁻_4],
        color = "red",
        linestyle = :dashdot,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-1.5, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )

    savefig("./scripts_compare/fig/crystal_dip_mixture.pdf")
end

PhaseVelo_cd_mixture([0.01:0.01:10;], 0.05, 0.5, 10^2, 0.04, 2, 8.3, 0.01, 0.3)




















