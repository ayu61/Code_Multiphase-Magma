using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"
include("../scripts_mixture/dispersion_mixture.jl")
include("../scripts_TFM/dispersion_TFM.jl")


function AttenuationPlot(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)

    Reθ⁺_Mixture = Dispersion(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[1]
    Reθ⁻_Mixture = Dispersion(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[2]

    Reθ1_TFM = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[1]
    Reθ2_TFM = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[2]
    Reθ3_TFM = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[3]

    Imθ⁻_Mixture = Dispersion(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[4]

    Imθ1_TFM = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[4]
    Imθ2_TFM = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[5]

    vp_Mixture = zeros(length(k))
    vp_TFM = zeros(length(k))
    for i in [1:length(k);]
        vp_Mixture[i] = abs(Imθ⁻_Mixture[i]) / k[i]
        vp_TFM[i] = abs(Imθ2_TFM[i]) / k[i]
    end

    println("Mixture max: ", maximum(vp_Mixture)*3580)
    println("Mixture min: ", minimum(vp_Mixture)*3580)
    println("TFM max: ", maximum(vp_TFM)*3580)
    println("TFM min: ", minimum(vp_TFM)*3580)

    #println(Imθ1_TFM)

    plt = default(
        xlabel = L"Wave number $[-]$",
        tickfontsize = 12,
        guidefontsize = 14,
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        legend = :bottomleft,
    )

    plt = plot(k, vp_Mixture,
        ylabel = L"$v_\mathrm{p} \,[-]$",
        #ylim = (0.23, 0.27),
        color = "black",
        linestyle = :solid,
        linewidth = 1.7,
        label = "Mixture model",
        )
    
    plt = plot!(k, vp_TFM,
        ylabel = L"$v_\mathrm{p} \,[-]$",
        color = "black",
        linewidth = 1.7,
        label = "Effective Two-fluid model",
        linestyle = :dash,
    )

    plt = plot!(twinx(), k, Reθ⁺_Mixture,
        ylim = (-0.4,0),
        label=L"$\mathrm{Re} \,\,[\theta_2]$", 
        linewidth = 1.5,
        alpha = 0.5, 
        ylabel = L"Attenuation Factor $[-]$",
        legend = false,
        color = "red",
        linestyle = :solid
    )
    plt = plot!(twinx(), k, Reθ2_TFM,
        ylim = (-0.4,0),
        label=L"$\mathrm{Re} \,\,[\theta_3]$", 
        linewidth = 1.5,
        alpha = 0.5, 
        ylabel = L"Attenuation Factor $[-]$",
        legend = false,
        color = "red",
        linestyle = :dash
    )

    savefig("scripts_compare/fig/basic_compare.pdf")
end

AttenuationPlot([0.01:0.001:10;], 0.05, 0.5, 10^2, 0.04, 2, 0.01, 0.3)