using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"
include("dispersion_TFM.jl")


function AttenuationPlot(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)

    Reθ1 = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[1]
    Reθ2 = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[2]
    Reθ3 = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[3]

    Imθ1 = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[4]
    Imθ2 = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[5]
    Imθ3 = Dispersion_TFM(k, α0, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[6]

    vp1 = zeros(length(k))
    vp2 = zeros(length(k))
    vp3 = zeros(length(k))
    for i in [1:length(k);]
        vp1[i] = abs(Imθ1[i]) / k[i]
        vp2[i] = abs(Imθ2[i]) / k[i]
        vp3[i] = abs(Imθ3[i]) / k[i]
    end

    plt = default(
        xlabel = L"Wave number $[-]$",
        title = "Effective Two-Fluid model",
        tickfontsize = 12,
        guidefontsize = 14,
        legendfontsize = 11,
        titlefontsize = 14,
        fontfamily = plot_font,
        size = (600,350),
        rightmargin = 1.5Plots.cm,
    )

    plt = plot(k, vp1,
        ylabel = L"$v_\mathrm{p} \,[-]$",
        color = "black",
        linewidth = 1.7,
        label = L"$v_\mathrm{p}$",
        legend = false,
        linestyle = :solid,
        ylim = (0,0.5)
    )
    plt = plot!(k, vp2,
        ylabel = L"$v_\mathrm{p} \,[-]$",
        color = "black",
        linewidth = 1.7,
        label = L"$v_\mathrm{p}$",
        legend = false,
        linestyle = :solid,
        ylim = (0,0.5)
    )
    plt = plot!(k, vp3,
        ylabel = L"$v_\mathrm{p} \,[-]$",
        color = "black",
        linewidth = 1.7,
        label = L"$v_\mathrm{p}$",
        legend = false,
        linestyle = :solid,
        ylim = (0,0.5)
    )

    #plt = plot!(twinx(), k, Reθ1,
    #    ylim = (-8,0),
    #    label=L"$\mathrm{Re} \,\,[\theta_1]$", 
    #    linewidth = 1.5,
    #    alpha = 0.5, 
    #    ylabel = L"Attenuation Factor $[-]$",
    #    legend = (0.8,0.8),
    #    color = "red",
    #)
    plt = plot!(twinx(), k, Reθ2,
        ylim = (-8,0),
        label=L"$\mathrm{Re} \,\,[\theta_2]$", 
        linewidth = 1.5,
        alpha = 0.5, 
        ylabel = L"Attenuation Factor $[-]$",
        legend = (0.8,0.65),
        color = "red",
        linestyle = :solid
    )
    plt = plot!(twinx(), k, Reθ3,
        ylim = (-8,0),
        label=L"$\mathrm{Re} \,\,[\theta_3]$", 
        linewidth = 1.5,
        alpha = 0.5, 
        ylabel = L"Attenuation Factor $[-]$",
        legend = (0.8,0.5),
        color = "red",
        linestyle = :dot
    )

    savefig("scripts_TFM/fig/basic.pdf")
end

AttenuationPlot([0.01:0.01:100;], 0.05, 0.1, 10^2, 0.04, 2, 0.0001, 0.3)