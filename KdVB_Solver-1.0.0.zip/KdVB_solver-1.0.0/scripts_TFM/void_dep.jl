using Plots;gr()
using LaTeXStrings
plot_font = "Computer Modern"
include("dispersion_TFM.jl")


function PhaseVelo_Void(k, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)
    Imθ_1 = Dispersion_TFM(k, 0.001, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[5]
    Imθ_2 = Dispersion_TFM(k, 0.01, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[5]
    Imθ_3 = Dispersion_TFM(k, 0.05, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[5]
    Imθ_4 = Dispersion_TFM(k, 0.10, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[5]

    vp1 = zeros(length(k))
    vp2 = zeros(length(k))
    vp3 = zeros(length(k))
    vp4 = zeros(length(k))
    for i in [1:length(k);]
        vp1[i] = abs(Imθ_1[i]) / k[i]
        vp2[i] = abs(Imθ_2[i]) / k[i]
        vp3[i] = abs(Imθ_3[i]) / k[i]
        vp4[i] = abs(Imθ_4[i]) / k[i]
    end

    Reθ⁺_1 = Dispersion_TFM(k, 0.001, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[2]
    Reθ⁻_1 = Dispersion_TFM(k, 0.001, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[3]

    Reθ⁺_2 = Dispersion_TFM(k, 0.010, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[2]
    Reθ⁻_2 = Dispersion_TFM(k, 0.010, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[3]

    Reθ⁺_3 = Dispersion_TFM(k, 0.050, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[2]
    Reθ⁻_3 = Dispersion_TFM(k, 0.050, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[3]

    Reθ⁺_4 = Dispersion_TFM(k, 0.100, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[2]
    Reθ⁻_4 = Dispersion_TFM(k, 0.100, R0mm_ast, μL_ast, φP, rp, Δ, σ_ast)[3]

    plt = default(
        xlabel = L"Wave number $[-]$",
        #yscale = :log10,
        tickfontsize = 12,
        guidefontsize = 14,
        linewidth = 1.7,
        legend = (0.15, 0.6),
        legendfontsize = 11,
        fontfamily = plot_font,
        rightmargin = 1.5Plots.cm,
        foreground_color_legend = nothing,
        background_color_legend = nothing,
    )

    plt = plot(k, vp1, 
        color="black", 
        linestyle = :solid,
        label=L"$\alpha_0 = 0.001$",
        ylim = (0, 2),
        ylabel = L"$v_\mathrm{p} \,[-]$",
    )
    plt = plot!(k, vp2, 
        color="black", 
        linestyle = :dash,
        label=L"$\alpha_0 = 0.010$"
    )
    plt = plot!(k, vp3, 
        color="black", 
        linestyle = :dot,
        label=L"$\alpha_0 = 0.050$"
    )
    plt = plot!(k, vp4, 
        color="black", 
        linestyle = :dashdot,
        label=L"$\alpha_0 = 0.100$"
    )

    plt = plot!(twinx(), k, [Reθ⁺_1, Reθ⁻_1],
        color = "red",
        linestyle = :solid,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-4, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_2, Reθ⁻_2],
        color = "red",
        linestyle = :dash,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-4, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_3, Reθ⁻_3],
        color = "red",
        linestyle = :dot,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-4, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )
    plt = plot!(twinx(), k, [Reθ⁺_4, Reθ⁻_4],
        color = "red",
        linestyle = :dashdot,
        legend = false,
        ylabel = L"Attenuation Factor$\,[-]$",
        ylim = (-4, 0),
        linewidth = 1.5,
        alpha = 0.3,
    )

    savefig("./scripts_TFM/fig/PhaseVelo_Void.pdf")
end

#Attenuation([0.01:0.01:10;], 0.5, 10^2, 0.25, 2, 0.01, 0.3)
PhaseVelo_Void([0.01:0.001:10;], 0.5, 10^2, 0.04, 2, 0.01, 0.3)